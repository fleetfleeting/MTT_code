The Ground Truth in this form is:

frameIndex: the frame index of corresponding groundtruth in gtCenterAll and gtCornersAll
gtCenterAll: [center_x; center_y]
gtCornersAll: [topleft_x botleft_x botright_x topright_x topleft_x;
               topleft_y botleft_y botright_y topright_y topleft_y]


***********************************************************************
If you are going to use sequence 'panda', please cite our paper:

Wei Zhong, Huchuan Lu and Ming-Hsuan Yang, "Robust Object Tracking via Sparsity-based Collaborative Model", IEEE Internaltional Conference on Computer Vision and Pattern Recogintion, 2012 (CVPR 2012).